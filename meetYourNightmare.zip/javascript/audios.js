document.getElementById('play').addEventListener('click', function (e) {
    e.preventDefault();
    document.getElementById('audio').play();
    audio.volume = 0.2;  
  });